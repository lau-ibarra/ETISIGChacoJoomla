// We do this in this rather complicated manner since Joomla groups 
// external javascript includes and script declarations seperately 
// and this call has to be made right after loading jQuery.

jQuery.noConflict();